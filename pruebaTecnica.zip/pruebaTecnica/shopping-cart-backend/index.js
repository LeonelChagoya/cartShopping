const exprees = require("express");
const cors = require("cors");

const products = require("./products");



const app = exprees();
app.use(exprees.json());
app.use(cors());
app.use(exprees.static(__dirname + '/'));
// app.get('/', (req, res) => {
//     res.sendFile(__dirname + '/index.html');
//   });

app.get("/",(req,res)=>{
    res.send("Welcome to ur online shop Api...")
})
app.get("/products",(req,res)=>{
    res.send(products)
})



const port = process.env.PORT || 5021;
app.listen(port,console.log(` Server runnnig on port ${port}` ))