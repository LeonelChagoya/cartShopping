
const products=[
    
    {
       
        id:1,
        name:"Monitor Odyssey",
        desc:"27 Odyssey G55T WQHD 1000R Curved Gaming Monitor",
        price:319.19,
        image:"http://localhost:5021/images/pantall.jpg"
    },
    {
        id:2,
        name:"HyperX Alloy ",
        desc:"HyperX Alloy Origins Core - Tenkeyless Mechanical Gaming Keyboard,",
        price:90.59,
        image:"http://localhost:5021/images/teclado.jpg"
    },
    {
        id:3,
        name:"GeForce Graphics Cards",
        desc:"NVIDIA GeForce RTX 4080",
        price:1119.00,
        image:"http://localhost:5021/images/tarjetaGrafica.jpg"
    }
];

module.exports = products;