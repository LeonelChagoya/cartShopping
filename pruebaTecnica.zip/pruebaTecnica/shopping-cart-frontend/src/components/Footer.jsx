
const Footer = () => {
    return (  <div>
        <footer className='footer'>
            <span className='text-muted'>All Rights Reserved 2023 @leonelChagoya</span>
        </footer>
      </div> );
}
 
export default Footer;