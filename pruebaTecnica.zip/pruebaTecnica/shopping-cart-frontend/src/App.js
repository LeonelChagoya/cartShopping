import React from 'react';
import "./App.css";
import "react-toastify/dist/ReactToastify.css";
import { BrowserRouter as Router, Routes, Route,Navigate} from "react-router-dom";
import {ToastContainer} from "react-toastify"
import Cart from  './components/Cart';
import Navbar from './components/Navbar';
import Home from './components/Home';
import NotFound from './components/NotFound';
import Footer from './components/Footer';

function App() {
  return (   

      <Router>
        <ToastContainer></ToastContainer>
      <Navbar/>
      <Routes>
        <Route exact path='/' element={<Home/>} />
        <Route exact path='/cart' element={<Cart/>} />
        <Route exact path='/not-found' element={<NotFound/>} />
        <Route path="*" element={<Navigate to ="/not-found" />}/>
      </Routes>    
        <Footer/>
      </Router>  
  );
}

export default App;
